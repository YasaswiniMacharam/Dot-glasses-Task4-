const products = [
  {
    id: 1,
    name: 'Retro Sunglasses',
    price: 999,
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRlpftn-vAFwTt6pfhm4f2s0Ipdnn7YCG3NTw&s',
  },
  {
    id: 2,
    name: 'Classic Eyeglasses',
    price: 1299,
    image: 'https://www.shutterstock.com/image-photo/pair-blue-prescription-eye-glasses-260nw-2472127101.jpg',
  },
  {
    id: 3,
    name: 'Round Frame Glasses',
    price: 1199,
    image: 'https://m.media-amazon.com/images/I/51c9chOPgQL._AC_UY1100_.jpg',
  },
];

export default products;
