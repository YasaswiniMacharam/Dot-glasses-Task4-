// src/pages/CartPage.js
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const CartPage = () => {
  const [cartItems, setCartItems] = useState([]);

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem('cart')) || [];
    setCartItems(saved);
  }, []);

  // Save updated cart to localStorage
  const updateLocalStorage = (items) => {
    setCartItems(items);
    localStorage.setItem('cart', JSON.stringify(items));
  };

  // Add quantity of item
  const handleAdd = (id) => {
    const updated = cartItems.map((item) =>
      item.id === id ? { ...item, quantity: item.quantity + 1 } : item
    );
    updateLocalStorage(updated);
  };

  // Remove quantity of item (remove item if quantity reaches 0)
  const handleRemove = (id) => {
    const updated = cartItems
      .map((item) =>
        item.id === id ? { ...item, quantity: item.quantity - 1 } : item
      )
      .filter((item) => item.quantity > 0);
    updateLocalStorage(updated);
  };

  return (
    <div style={{ padding: '20px', maxWidth: '800px', margin: 'auto' }}>
      <h2>Your Cart</h2>

      {cartItems.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {cartItems.map((item, index) => (
            <li
              key={index}
              style={{
                display: 'flex',
                alignItems: 'center',
                borderBottom: '1px solid #ddd',
                padding: '10px 0',
              }}
            >
              <img
                src={item.image}
                alt={item.name}
                style={{ width: '100px', height: 'auto', marginRight: '20px', borderRadius: '8px' }}
              />
              <div style={{ flexGrow: 1 }}>
                <h3 style={{ margin: '0 0 5px 0' }}>{item.name}</h3>
                <p style={{ margin: 0, fontWeight: 'bold' }}>₹{item.price}</p>
              </div>

              {/* Quantity controls */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <button
                  onClick={() => handleRemove(item.id)}
                  style={{
                    padding: '5px 10px',
                    fontSize: '18px',
                    cursor: 'pointer',
                    borderRadius: '4px',
                    border: '1px solid #ccc',
                    backgroundColor: '#f8f8f8',
                  }}
                >
                  −
                </button>
                <span style={{ minWidth: '20px', textAlign: 'center', fontSize: '16px' }}>
                  {item.quantity || 1}
                </span>
                <button
                  onClick={() => handleAdd(item.id)}
                  style={{
                    padding: '5px 10px',
                    fontSize: '18px',
                    cursor: 'pointer',
                    borderRadius: '4px',
                    border: '1px solid #ccc',
                    backgroundColor: '#f8f8f8',
                  }}
                >
                  +
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}

      <Link to="/checkout">
        <button
          disabled={cartItems.length === 0}
          style={{
            marginTop: '30px',
            padding: '12px 25px',
            fontSize: '16px',
            cursor: cartItems.length === 0 ? 'not-allowed' : 'pointer',
            backgroundColor: cartItems.length === 0 ? '#aaa' : '#007bff',
            color: 'white',
            border: 'none',
            borderRadius: '5px',
          }}
        >
          Go to Checkout
        </button>
      </Link>
    </div>
  );
};

export default CartPage;
