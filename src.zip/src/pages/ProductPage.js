import React from 'react';
import { Link } from 'react-router-dom';
import products from '../data/products';
import ProductCard from '../components/ProductCard';
import '../App.css';

const ProductPage = () => {
  const addToCart = (product) => {
    const savedCart = JSON.parse(localStorage.getItem('cart')) || [];
    const exists = savedCart.find(item => item.id === product.id);
    if (exists) {
      const updatedCart = savedCart.map(item =>
        item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
      );
      localStorage.setItem('cart', JSON.stringify(updatedCart));
    } else {
      localStorage.setItem('cart', JSON.stringify([...savedCart, { ...product, quantity: 1 }]));
    }
    alert(`${product.name} added to cart!`);
  };

  return (
    <div className="container">
      <h2>Choose Your Glasses</h2>

      <div className="product-grid">
        {products.map(product => (
          <ProductCard key={product.id} product={product} addToCart={addToCart} />
        ))}
      </div>

      {/* Button directly below product grid, centered */}
      <div style={{ textAlign: 'center', marginTop: '10px' }}>
        <Link to="/cart">
          <button
            style={{
              padding: '12px 25px',
              backgroundColor: '#28a745',
              color: 'white',
              border: 'none',
              borderRadius: '5px',
              cursor: 'pointer',
              fontSize: '16px',
            }}
          >
            Go to Cart
          </button>
        </Link>
      </div>
    </div>
  );
};

export default ProductPage;
