import React, { useEffect, useState } from 'react';

const ThankYouPage = () => {
  const [order, setOrder] = useState(null);

  useEffect(() => {
    const orderData = JSON.parse(localStorage.getItem('orderDetails') || '{}');
    setOrder(orderData);

    // Optional: Clear cart after successful order
    localStorage.removeItem('cart');
  }, []);

  if (!order || !order.items || order.items.length === 0) {
    return (
      <div className="container">
        <h2>No order found</h2>
        <p>Please place an order first.</p>
      </div>
    );
  }

  return (
    <div className="container">
      <h2>Thank You for Your Order!</h2>
      <p><strong>Name:</strong> {order.name}</p>
      <p><strong>Address:</strong> {order.address}</p>
      <p><strong>Contact:</strong> {order.contact}</p>

      <h3>Items Ordered:</h3>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
        {order.items.map((item, index) => (
          <div
            key={index}
            style={{
              display: 'flex',
              alignItems: 'center',
              border: '1px solid #ccc',
              borderRadius: '8px',
              padding: '10px',
              gap: '15px',
            }}
          >
            <img
              src={item.image}
              alt={item.name}
              style={{ width: '80px', height: '80px', objectFit: 'cover', borderRadius: '5px' }}
            />
            <div style={{ flex: 1 }}>
              <p style={{ margin: 0 }}><strong>{item.name}</strong></p>
              <p style={{ margin: 0 }}>
                ₹{item.price} × {item.quantity} = ₹{(item.price * item.quantity).toFixed(2)}
              </p>
            </div>
          </div>
        ))}
      </div>

      <h3 style={{ marginTop: '20px' }}>Total: ₹{order.total?.toFixed(2)}</h3>
    </div>
  );
};

export default ThankYouPage;
