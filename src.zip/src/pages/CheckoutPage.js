import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const CheckoutPage = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    contact: '',
    discount: '',
  });

  const [cartItems, setCartItems] = useState([]);

  useEffect(() => {
    const savedCart = JSON.parse(localStorage.getItem('cart')) || [];
    setCartItems(savedCart);
  }, []);

  const totalPrice = cartItems.reduce(
    (total, item) => total + item.price * (item.quantity || 1),
    0
  );

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Save both form data and cart data
    const orderDetails = {
      ...formData,
      items: cartItems,
      total: totalPrice,
    };
    localStorage.setItem('orderDetails', JSON.stringify(orderDetails));
    navigate('/thank-you');
  };

  return (
    <div className="container">
      <h2>Checkout</h2>

      {cartItems.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <>
          <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '20px' }}>
            <thead>
              <tr>
                <th style={{ textAlign: 'left', borderBottom: '1px solid #ccc', padding: '8px' }}>Product</th>
                <th style={{ textAlign: 'center', borderBottom: '1px solid #ccc', padding: '8px' }}>Quantity</th>
                <th style={{ textAlign: 'right', borderBottom: '1px solid #ccc', padding: '8px' }}>Price</th>
                <th style={{ textAlign: 'right', borderBottom: '1px solid #ccc', padding: '8px' }}>Subtotal</th>
              </tr>
            </thead>
            <tbody>
              {cartItems.map((item, i) => (
                <tr key={i}>
                  <td style={{ padding: '8px' }}>{item.name}</td>
                  <td style={{ textAlign: 'center', padding: '8px' }}>{item.quantity}</td>
                  <td style={{ textAlign: 'right', padding: '8px' }}>₹{item.price}</td>
                  <td style={{ textAlign: 'right', padding: '8px' }}>₹{(item.price * item.quantity).toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <h3 style={{ textAlign: 'right' }}>Total: ₹{totalPrice.toFixed(2)}</h3>

          <form onSubmit={handleSubmit} style={{ marginTop: '20px' }}>
            <input
              type="text"
              name="name"
              placeholder="Full Name"
              value={formData.name}
              onChange={handleChange}
              required
              style={{ display: 'block', margin: '10px 0', width: '100%', padding: '10px' }}
            />
            <input
              type="text"
              name="address"
              placeholder="Address"
              value={formData.address}
              onChange={handleChange}
              required
              style={{ display: 'block', margin: '10px 0', width: '100%', padding: '10px' }}
            />
            <input
              type="tel"
              name="contact"
              placeholder="Contact Number"
              value={formData.contact}
              onChange={handleChange}
              required
              style={{ display: 'block', margin: '10px 0', width: '100%', padding: '10px' }}
            />
            <input
              type="text"
              name="discount"
              placeholder="Discount Code (Optional)"
              value={formData.discount}
              onChange={handleChange}
              style={{ display: 'block', margin: '10px 0', width: '100%', padding: '10px' }}
            />

            <button
              type="submit"
              style={{
                padding: '12px 25px',
                backgroundColor: '#28a745',
                color: 'white',
                border: 'none',
                borderRadius: '5px',
                cursor: 'pointer',
                fontSize: '16px',
              }}
            >
              Place Order
            </button>
          </form>
        </>
      )}
    </div>
  );
};

export default CheckoutPage;
