const Cart = ({ cartItems, onRemove }) => (
  <div>
    <h2>Cart</h2>
    {cartItems.map((item, index) => (
      <div key={index}>
        {item.name} - ${item.price}
        <button onClick={() => onRemove(index)}>Remove</button>
      </div>
    ))}
  </div>
);

export default Cart;
