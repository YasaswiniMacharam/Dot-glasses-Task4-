const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

app.post('/order', (req, res) => {
  console.log('Received Order:', req.body);
  res.status(200).send({ message: 'Order received' });
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
CheckoutPage.js

jsx
Copy
Edit
